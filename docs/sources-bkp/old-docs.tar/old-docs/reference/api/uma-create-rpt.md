## API Document

### /requester/rpt

#### Overview


#### `/requester/rpt`
##### getRequesterPermissionToken
**POST** `/requester/rpt`

The endpoint at which the requester asks the AM to issue an RPT.

###### URL
    http://gluu.org/requester/rpt

###### Parameters
- header

    <table border="1">
        <tr>
            <th>Parameter</th>
            <th>Required</th>
            <th>Description</th>
            <th>Data Type</th>
        </tr>
        <tr>
            <th>Authorization</th>
            <td>false</td>
            <td></td>
            <td>string</td>
        </tr>
        <tr>
            <th>Host</th>
            <td>false</td>
            <td></td>
            <td>string</td>
        </tr>
    </table>

###### Response
[](#)


###### Errors
<table border="1">
    <tr>
        <th>Status Code</th>
        <th>Reason</th>
    </tr>
        <tr>
            <td>401</td>
            <td>Unauthorized</td>
        </tr>
</table>

- - -

## Data Types
