
## Scope To Claims Mapping File

This file does a mapping between the scopes and the different claims
that are used by the Gluu Server. The mapping has a [JSON][json]
structure.

```
    {
    "claimMapping":[
        {
            "ldap":"uid",
            "claim":"sub"
        },
        {
            "ldap":"displayName",
            "claim":"name"
        },
        {
            "ldap":"givenName",
            "claim":"given_name"
        },
        {
            "ldap":"sn",
            "claim":"family_name"
        },
        {
            "ldap":"photo1",
            "claim":"picture"
        },
        {
            "ldap":"timezone",
            "claim":"zoneinfo"
        },
        {
            "ldap":"preferredLanguage",
            "claim":"locale"
        },
        {
            "ldap":"mail",
            "claim":"email"
        },
        {
            "ldap":"homePostalAddress",
            "claim":"formatted"
        },
        {
            "ldap":"street",
            "claim":"street_address"
        },
        {
            "ldap":"l",
            "claim":"locality"
        },
        {
            "ldap":"st",
            "claim":"region"
        },
        {
            "ldap":"c",
            "claim":"country"
        },
        {
            "ldap":"postalCode",
            "claim":"postal_code"
        },
        {
            "ldap":"telephoneNumber",
            "claim":"phone_number"
        },
        {
            "ldap":"oxInum",
            "claim":"inum"
        }
    ],
    "baseDn":{
        "appliance":"ou=appliances,o=gluu",
        "people":"ou=people,o=%(inumOrg)s,o=gluu",
        "groups":"ou=groups,o=%(inumOrg)s,o=gluu",
        "clients":"ou=clients,o=%(inumOrg)s,o=gluu",
        "scopes":"ou=scopes,o=%(inumOrg)s,o=gluu",
        "attributes":"ou=attributes,o=%(inumOrg)s,o=gluu",
        "sessionId":"ou=session,o=%(inumOrg)s,o=gluu",
        "federationMetadata":"ou=metadata,ou=federation,o=%(inumOrg)s,o=gluu",
        "federationRP":"ou=rp,ou=federation,o=%(inumOrg)s,o=gluu",
        "federationOP":"ou=op,ou=federation,o=%(inumOrg)s,o=gluu",
        "federationRequest":"ou=request,ou=federation,o=%(inumOrg)s,o=gluu",
        "federationTrust":"ou=trust,ou=federation,o=%(inumOrg)s,o=gluu",
        "umaBase":"ou=uma,o=%(inumOrg)s,o=gluu",
        "umaPolicy":"ou=policies,ou=uma,o=%(inumOrg)s,o=gluu"
      }
    }
```

[json]: https://en.wikipedia.org/wiki/JSON "JSON, Wikipedia"

