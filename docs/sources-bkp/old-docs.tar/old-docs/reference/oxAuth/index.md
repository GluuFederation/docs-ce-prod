# oxAuth Configuration 

The oxAuth configuration consists of these subsections:

- [oxAuth LDAP properties](./oxauth-ldap-properties.md)

- [oxAuth XML configuration](./oxauth-config.md)

- [scope to claims mapping file](./oxauth-scope-to-claims-mapping-file.md)

