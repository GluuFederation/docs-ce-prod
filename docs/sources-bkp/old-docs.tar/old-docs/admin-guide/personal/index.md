# Personal

The Personal section of the oxTrust application, shown below, provides a
user with some basic details about their account within the Gluu Server.
Currently all information is static, but we plan on developing it out so
the user can perform basic self-service profile management.

![personal oxtrust view](https://raw.githubusercontent.com/GluuFederation/docs/master/sources/img/2.4/admin_personal_profile.png)
