# Using OpenID Connect from JavaScript

See [OpenID Connect plugin for Passport](http://www.gluu.co/.qqh2) for
further details.


