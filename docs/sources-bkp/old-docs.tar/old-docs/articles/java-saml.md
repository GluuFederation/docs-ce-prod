# Java SAML

## Libraries

The [Gluu SAML Library](../../../../../oxTrust/tree/master/saml-openid-auth-client) provides a simple Java SP implementation without request signing.



